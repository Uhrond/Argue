﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class sql : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["BddProd_CS"].ConnectionString);
        
        myConnection.Open();

        SqlCommand myCommand = new SqlCommand("select * from TEST", myConnection);
        SqlDataReader myReader = myCommand.ExecuteReader();
        while (myReader.Read())
        {
            Literal1.Text += myReader["col2"].ToString();
        }
        myConnection.Close();

    }
}
