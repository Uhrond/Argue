﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.DynamicData;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class ArgueV2 : System.Web.UI.Page
{
    //Chargement des templates
    private static String mapPath = HttpContext.Current.Server.MapPath("~/");
    private StringBuilder Template_Header = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Header.html"));
    private StringBuilder Template_Poc = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Poc.html"));
    private StringBuilder Template_ArgueGlobal = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueGlobal.html"));
    private StringBuilder Template_ArgueLeft = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueLeft.html"));
    private StringBuilder Template_ReponseLeft = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ReponseLeft.html"));
    private StringBuilder Template_ReponseRight = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ReponseRight.html"));
    private StringBuilder Template_Timeline = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Timeline.html"));
    private StringBuilder Template_ArgueRight = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueRight.html"));
    private StringBuilder Template_Footer = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Footer.html"));
    private StringBuilder Template_Signaler = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Signaler.html"));
    private StringBuilder Template_Login = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Login.html"));
    private StringBuilder Template_Share = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Share.html"));
    private StringBuilder Template_GoogleAnalytics = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/GoogleAnalytics.html"));

    //Chargement des DAO
    private PoCDAO pocdao = new PoCDAO();
    private ArgueDAO arguedao = new ArgueDAO();
    private ReponseDAO reponsedao = new ReponseDAO();

    protected void Page_Load(object sender, EventArgs e)
    {
        StringBuilder HTML = new StringBuilder();

        //Récupération de l'id du PoC dans l'url
        int Id_PoC = -1;
        int res;
        if (Request.QueryString["PoC"] != "" && Request.QueryString["PoC"] != null && Int32.TryParse(Request.QueryString["PoC"], out res))
            Id_PoC = Convert.ToInt32(Request.QueryString["PoC"]);
        else
            new Error("404");

        /* Ajout d'une vue supplémentaire au PoC */
        pocdao.Insert_Vue_PoC(Id_PoC);

        //Recherche dans la bdd du Poc
        PoCOBJ PoC = pocdao.Get_PoC(Id_PoC);

        //Construction de la page
        //Ecriture des balises meta
        if (PoC.Titre.Length > 14)
            Page.Title = "PoC" + PoC.Titre.Substring(14, PoC.Titre.Length - 14);
        Page.MetaDescription = ConfigurationManager.AppSettings["Description"] +  PoC.Titre;
        Page.MetaKeywords = ConfigurationManager.AppSettings["MotsCles"] + String.Join(", ", PoC.Titre.Split(' ').Where(n => n.Length > 2).ToArray());

        //header
        HTML.Append(Template_Header.ToString());

        //share button
        HTML.Append(Template_Share.ToString());

        //Poc
        HTML.Append(Template_Poc.ToString());
        HTML.Replace("@Id_PoC@", PoC.Id.ToString());
        if (!String.IsNullOrEmpty(PoC.User.Avatar))
            HTML.Replace("@Avatar@", PoC.User.Avatar);
        else
            HTML.Replace("@Avatar@", "../Ressources/avatar_std.svg");

        HTML.Replace("@Titre@", PoC.Titre);
        HTML.Replace("@Login@", PoC.User.Login);
        HTML.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", PoC.DateCreation));
        HTML.Replace("@Content@", PoC.Content);
        Int32 VoteTotal = PoC.NbVotePour + PoC.NbVoteContre;
        Int32 VotePour = 50;
        Int32 VoteContre = 50;
        if (VoteTotal != 0)
        {
            VotePour = Convert.ToInt32(Math.Round(Convert.ToDouble((PoC.NbVotePour * 100) / VoteTotal)));
            VoteContre = 100 - VotePour;
        }
        HTML.Replace("@VoteContre@", VoteContre.ToString());
        HTML.Replace("@VotePour@", VotePour.ToString());
        HTML.Replace("@Vue@", PoC.NbVue.ToString());
        HTML.Replace("@Signaler@", Template_Signaler.ToString());

        //ArgueGlobal
        HTML.Append(Template_ArgueGlobal.ToString());

        List<ArgueOBJ> LstArgue = arguedao.Get_ListArgue(Id_PoC);
        //Argue Left
        StringBuilder sb_ArgueLeft = new StringBuilder();
        foreach (ArgueOBJ Argue in LstArgue)
        {
            if (Argue.PoC)
            {
                sb_ArgueLeft.Append(Template_ArgueLeft.ToString());
                sb_ArgueLeft.Replace("@Id_Argue@", Argue.Id.ToString());
                if (!String.IsNullOrEmpty(Argue.User.Avatar))
                    sb_ArgueLeft.Replace("@Avatar@", Argue.User.Avatar);
                else
                    sb_ArgueLeft.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                sb_ArgueLeft.Replace("@Login@", Argue.User.Login);
                sb_ArgueLeft.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Argue.DateCreation));
                sb_ArgueLeft.Replace("@Content@", Argue.Content);
                sb_ArgueLeft.Replace("@NbReponse@", Argue.NbReponse.ToString());
                sb_ArgueLeft.Replace("@like@", Argue.NbLike.ToString());
                sb_ArgueLeft.Replace("@dislike@", Argue.NbDisLike.ToString());
                sb_ArgueLeft.Replace("@Signaler@", Template_Signaler.ToString());

                StringBuilder sb_Reponse_Left = new StringBuilder();
                foreach (ReponseOBJ Reponse in reponsedao.Get_LstReponse(Argue.Id))
                {
                    sb_Reponse_Left.Append(Template_ReponseLeft.ToString());
                    sb_Reponse_Left.Replace("@Id_Reponse@", Reponse.Id.ToString());
                    if (!String.IsNullOrEmpty(Reponse.User.Avatar))
                        sb_Reponse_Left.Replace("@Avatar@", Reponse.User.Avatar);
                    else
                        sb_Reponse_Left.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                    sb_Reponse_Left.Replace("@Login@", Reponse.User.Login);
                    sb_Reponse_Left.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Reponse.DateCreation));
                    sb_Reponse_Left.Replace("@Content@", Reponse.Content);
                    sb_Reponse_Left.Replace("@Signaler@", Template_Signaler.ToString());

                }
                sb_ArgueLeft.Replace("@Template_ReponseLeft@", sb_Reponse_Left.ToString());
            }
        }
        HTML.Replace("@Template_ArgueLeft@", sb_ArgueLeft.ToString());

        //Timeline
        StringBuilder sb_timeline = new StringBuilder();
        sb_timeline.Append(Template_Timeline.ToString());
        HTML.Replace("@Template_Timeline@", sb_timeline.ToString());

        //Argue Right
        StringBuilder sb_ArgueRight = new StringBuilder();
        foreach (ArgueOBJ Argue in LstArgue)
        {
            if (!Argue.PoC)
            {
                sb_ArgueRight.Append(Template_ArgueRight.ToString());
                sb_ArgueRight.Replace("@Id_Argue@", Argue.Id.ToString());
                if (!String.IsNullOrEmpty(Argue.User.Avatar))
                    sb_ArgueRight.Replace("@Avatar@", Argue.User.Avatar);
                else
                    sb_ArgueRight.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                sb_ArgueRight.Replace("@Login@", Argue.User.Login);
                sb_ArgueRight.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Argue.DateCreation));
                sb_ArgueRight.Replace("@Content@", Argue.Content);
                sb_ArgueRight.Replace("@NbReponse@", Argue.NbReponse.ToString());
                sb_ArgueRight.Replace("@like@", Argue.NbLike.ToString());
                sb_ArgueRight.Replace("@dislike@", Argue.NbDisLike.ToString());
                sb_ArgueRight.Replace("@Signaler@", Template_Signaler.ToString());


                StringBuilder sb_Reponse_Right = new StringBuilder();
                foreach (ReponseOBJ Reponse in reponsedao.Get_LstReponse(Argue.Id))
                {
                    sb_Reponse_Right.Append(Template_ReponseRight.ToString());
                    sb_Reponse_Right.Replace("@Id_Reponse@", Reponse.Id.ToString());
                    if (!String.IsNullOrEmpty(Reponse.User.Avatar))
                        sb_Reponse_Right.Replace("@Avatar@", Reponse.User.Avatar);
                    else
                        sb_Reponse_Right.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                    sb_Reponse_Right.Replace("@Login@", Reponse.User.Login);
                    sb_Reponse_Right.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Reponse.DateCreation));
                    sb_Reponse_Right.Replace("@Content@", Reponse.Content);
                    sb_Reponse_Right.Replace("@Signaler@", Template_Signaler.ToString());

                }
                sb_ArgueRight.Replace("@Template_ReponseRight@", sb_Reponse_Right.ToString());
            }
        }
        HTML.Replace("@Template_ArgueRight@", sb_ArgueRight.ToString());

        //Footer
        HTML.Append(Template_Footer.ToString());

        //Ajout du login (hidden)
        HTML.Append(Template_Login.ToString());

        //Ajout de Google analytics à la page
        HTML.Append(Template_GoogleAnalytics.ToString());

        Html.Text = HTML.ToString();
    }

    /// <summary>
    /// fonction correspondant à un like
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    [WebMethod(enableSession: true)]
    public static string Like(int Id, string PoC_Ar)
    {
        //vérification que le user est connecté
        if (HttpContext.Current.Session["User"] == null)
        {
            return "Login";
        }
        else
        {
            PoCDAO pocdao = new PoCDAO();
            ArgueDAO arguedao = new ArgueDAO();
            int Id_User = ((UserOBJ)HttpContext.Current.Session["User"]).Id;
            if (PoC_Ar == "PoC")
            {
                if (pocdao.Get_Like_PoC(Id, Id_User))
                    pocdao.Delete_Like_PoC(Id, Id_User);
                else
                    pocdao.Insert_Like_PoC(Id, Id_User);
            }
            else
            {
                if (arguedao.Get_Like_Argue(Id, Id_User))
                    arguedao.Delete_Like_Argue(Id, Id_User);
                else
                    arguedao.Insert_Like_Argue(Id, Id_User); ;
            }
            return "Ok";
        }
    }

    /// <summary>
    /// fonction correspondant à un DisLike
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    [WebMethod(enableSession: true)]
    public static string DisLike(int Id, string PoC_Ar)
    {
        //vérification que le user est connecté
        if (HttpContext.Current.Session["User"] == null)
        {
            return "Login";
        }
        else
        {
            PoCDAO pocdao = new PoCDAO();
            ArgueDAO arguedao = new ArgueDAO();
            int Id_User = ((UserOBJ)HttpContext.Current.Session["User"]).Id;
            if (PoC_Ar == "PoC")
            {
                //if (pocdao.Get_Dislike_PoC(Id, Id_User).Count == 0)
                //    pocdao.Delete_Dislike_PoC(Id, Id_User);
                //else
                //    pocdao.Insert_Dislike_PoC(Id, Id_User);
            }
            else
            {
                //if (arguedao.Get_Dislike_Argue(Id, Id_User).Count == 0)
                //    arguedao.Delete_Dislike_Argue(Id, Id_User);
                //else
                //    arguedao.Insert_Dislike_Argue(Id, Id_User); 
            }
            return "Ok";
        }
    }

    /// <summary>
    /// fonction qui récupère tous les like et dislike d'un poc d'un user
    /// </summary>
    /// <param name="Id"></param>
    /// <returns></returns>
    [WebMethod(enableSession: true)]
    public static string LikeDislike(int Id_PoC)
    {
        if (HttpContext.Current.Session["User"] != null)
        {
            Dictionary<string, List<int>> dic = new Dictionary<string, List<int>>();

            PoCDAO pocdao = new PoCDAO();
            ArgueDAO arguedao = new ArgueDAO();
            ReponseDAO reponsedao = new ReponseDAO();
            int Id_User = ((UserOBJ)HttpContext.Current.Session["User"]).Id;

            /* PoC */
            List<int> lstPoC = new List<int>();
            if (pocdao.Get_Like_PoC(Id_PoC, Id_User))
                lstPoC.Add(-1);

            lstPoC.AddRange(pocdao.Get_Dislike_PoC(Id_PoC, Id_User));

            dic.Add("PoC_" + Id_PoC, lstPoC);

            /* Argue */
            foreach (ArgueOBJ argue in arguedao.Get_ListArgue(Id_PoC))
            {
                List<int> lstArgue = new List<int>();
                if (arguedao.Get_Like_Argue(argue.Id, Id_User))
                    lstArgue.Add(-1);

                lstArgue.AddRange(arguedao.Get_Dislike_Argue(argue.Id, Id_User));

                dic.Add("Argue_" + argue.Id, lstArgue);

                /* Reponse */
                foreach (ReponseOBJ reponse in reponsedao.Get_LstReponse(argue.Id))
                {
                    List<int> lstReponse = new List<int>();
                    if (reponsedao.Get_Like_Reponse(reponse.Id, Id_User))
                        lstReponse.Add(-1);

                    lstReponse.AddRange(reponsedao.Get_Dislike_Reponse(reponse.Id, Id_User));

                    dic.Add("Reponse_" + reponse.Id, lstReponse);
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(dic);
        }
        else
            return null;
    }
}
