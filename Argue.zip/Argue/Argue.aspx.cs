﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.DynamicData;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class ArgueV2 : System.Web.UI.Page
{
    //Chargement des templates
    private static String mapPath = HttpContext.Current.Server.MapPath("~/");
    private StringBuilder Template_Header = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Header.html"));
    private StringBuilder Template_Poc = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Poc.html"));
    private StringBuilder Template_ArgueGlobal = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueGlobal.html"));
    private StringBuilder Template_ArgueLeft = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueLeft.html"));
    private StringBuilder Template_ReponseLeft = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ReponseLeft.html"));
    private StringBuilder Template_Timeline = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Timeline.html"));
    private StringBuilder Template_ArgueRight = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueRight.html"));
    private StringBuilder Template_Footer = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Footer.html"));
    private StringBuilder Template_Signaler = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Signaler.html"));

    //Chargement des DAO
    private PoCDAO pocdao = new PoCDAO();
    private ArgueDAO arguedao = new ArgueDAO();
    private ReponseDAO reponsedao = new ReponseDAO();

    protected void Page_Load(object sender, EventArgs e)
    {

        StringBuilder HTML = new StringBuilder();

        //Récupération de l'id du PoC dans l'url
        int Id_PoC = -1;
        int res;
        if (Request.QueryString["PoC"] != "" && Request.QueryString["PoC"] != null && Int32.TryParse(Request.QueryString["PoC"], out res))
            Id_PoC = Convert.ToInt32(Request.QueryString["PoC"]);
        else
            new Error("404");

        //Recherche dans la bdd du Poc
        PoCOBJ PoC = pocdao.Get_PoC(Id_PoC);

        //Construction de la page
        //Ecriture des balises meta
        if (PoC.Titre.Length > 14)
            Page.Title = "PoC" + PoC.Titre.Substring(14, PoC.Titre.Length - 14);
        Page.MetaKeywords = PoC.Titre;
        Page.MetaDescription = PoC.Titre;

        //header
        HTML.Append(Template_Header.ToString());

        //Poc
        HTML.Append(Template_Poc.ToString());
        HTML.Replace("@Id_PoC@", PoC.Id.ToString());
        if (!String.IsNullOrEmpty(PoC.User.Avatar))
            HTML.Replace("@Avatar@", PoC.User.Avatar);
        else
            HTML.Replace("@Avatar@", "../Ressources/avatar_std.svg");

        HTML.Replace("@Titre@", PoC.Titre);
        HTML.Replace("@Login@", PoC.User.Login);
        HTML.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", PoC.DateCreation));
        HTML.Replace("@Content@", PoC.Content);
        Int32 VoteTotal = PoC.NbVotePour + PoC.NbVoteContre;
        Int32 VotePour = 50;
        Int32 VoteContre = 50;
        if (VoteTotal != 0)
        {
            VotePour = Convert.ToInt32(Math.Round(Convert.ToDouble((PoC.NbVotePour * 100) / VoteTotal)));
            VoteContre = 100 - VotePour;
        }
        HTML.Replace("@VoteContre@", VoteContre.ToString());
        HTML.Replace("@VotePour@", VotePour.ToString());
        HTML.Replace("@Vue@", PoC.NbVue.ToString());
        HTML.Replace("@Signaler@", Template_Signaler.ToString());

        //ArgueGlobal
        HTML.Append(Template_ArgueGlobal.ToString());

        List<ArgueOBJ> LstArgue = arguedao.Get_ListArgue(Id_PoC);
        //Argue Left
        StringBuilder sb_ArgueLeft = new StringBuilder();
        foreach (ArgueOBJ Argue in LstArgue)
        {
            if (Argue.PoC)
            {
                sb_ArgueLeft.Append(sb_ArgueLeft.ToString() + Template_ArgueLeft.ToString());
                sb_ArgueLeft.Replace("@Id_Argue@", Argue.Id.ToString());
                if (!String.IsNullOrEmpty(Argue.User.Avatar))
                    sb_ArgueLeft.Replace("@Avatar@", Argue.User.Avatar);
                else
                    sb_ArgueLeft.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                sb_ArgueLeft.Replace("@Login@", Argue.User.Login);
                sb_ArgueLeft.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Argue.DateCreation));
                sb_ArgueLeft.Replace("@Content@", Argue.Content);
                sb_ArgueLeft.Replace("@NbReponse@", Argue.NbReponse.ToString());
                sb_ArgueLeft.Replace("@like@", Argue.NbLike.ToString());
                sb_ArgueLeft.Replace("@dislike@", Argue.NbDisLike.ToString());
                sb_ArgueLeft.Replace("@Signaler@", Template_Signaler.ToString());

                StringBuilder sb_Reponse_Left = new StringBuilder();
                foreach (ReponseOBJ Reponse in reponsedao.Get_LstReponse(Argue.Id))
                {
                    sb_Reponse_Left.Append(sb_Reponse_Left.ToString() + Template_ReponseLeft.ToString());
                    sb_Reponse_Left.Replace("@Id_Reponse@", Reponse.Id.ToString());
                    if (!String.IsNullOrEmpty(Reponse.User.Avatar))
                        sb_Reponse_Left.Replace("@Avatar@", Reponse.User.Avatar);
                    else
                        sb_Reponse_Left.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                    sb_Reponse_Left.Replace("@Login@", Reponse.User.Login);
                    sb_Reponse_Left.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Reponse.DateCreation));
                    sb_Reponse_Left.Replace("@Content@", Reponse.Content);
                    sb_Reponse_Left.Replace("@Signaler@", Template_Signaler.ToString());

                }
                sb_ArgueLeft.Replace("@Template_ReponseLeft@", sb_Reponse_Left.ToString());
            }
        }
        HTML.Replace("@Template_ArgueLeft@", sb_ArgueLeft.ToString());

        //Timeline
        StringBuilder sb_timeline = new StringBuilder();
        sb_timeline.Append(Template_Timeline.ToString());
        HTML.Replace("@Template_Timeline@", sb_timeline.ToString());

        //Argue Right
        StringBuilder sb_ArgueRight = new StringBuilder();
        foreach (ArgueOBJ Argue in LstArgue)
        {
            if (!Argue.PoC)
            {
                sb_ArgueRight.Append(sb_ArgueRight.ToString() + Template_ArgueRight.ToString());
                sb_ArgueRight.Replace("@Id_Argue@", Argue.Id.ToString());
                if (!String.IsNullOrEmpty(Argue.User.Avatar))
                    sb_ArgueRight.Replace("@Avatar@", Argue.User.Avatar);
                else
                    sb_ArgueRight.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                sb_ArgueRight.Replace("@Login@", Argue.User.Login);
                sb_ArgueRight.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Argue.DateCreation));
                sb_ArgueRight.Replace("@Content@", Argue.Content);
                sb_ArgueRight.Replace("@NbReponse@", Argue.NbReponse.ToString());
                sb_ArgueLeft.Replace("@like@", Argue.NbLike.ToString());
                sb_ArgueLeft.Replace("@dislike@", Argue.NbDisLike.ToString());
                sb_ArgueLeft.Replace("@Signaler@", Template_Signaler.ToString());


                StringBuilder sb_Reponse_Right = new StringBuilder();
                foreach (ReponseOBJ Reponse in reponsedao.Get_LstReponse(Argue.Id))
                {
                    sb_Reponse_Right.Append(sb_Reponse_Right.ToString() + Template_ReponseLeft.ToString());
                    sb_Reponse_Right.Replace("@Id_Reponse@", Reponse.Id.ToString());
                    if (!String.IsNullOrEmpty(Reponse.User.Avatar))
                        sb_Reponse_Right.Replace("@Avatar@", Reponse.User.Avatar);
                    else
                        sb_Reponse_Right.Replace("@Avatar@", "../Ressources/avatar_std.svg");
                    sb_Reponse_Right.Replace("@Login@", Reponse.User.Login);
                    sb_Reponse_Right.Replace("@DateCreation@", String.Format("{0:ddd, MMM d, yyyy}", Reponse.DateCreation));
                    sb_Reponse_Right.Replace("@Content@", Reponse.Content);
                    sb_Reponse_Right.Replace("@Signaler@", Template_Signaler.ToString());

                }
                sb_ArgueLeft.Replace("@Template_ReponseLeft@", sb_Reponse_Right.ToString());
            }
        }
        HTML.Replace("@Template_ArgueRight@", sb_ArgueRight.ToString());

        //Footer
        HTML.Append(Template_Footer.ToString());

        Html.Text = HTML.ToString();
    }

    /// <summary>
    /// fonction correspondant à un like, peut retourner "ok", "notlog", "error"
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    [WebMethod(enableSession: true)]
    public static string Like(string Id, string PoC_Ar)
    {
        string s = "notlog";
        //vérification que le user est connecté
        s = "ok";

        //ajout dans la bdd du like


        return s;
    }

    /// <summary>
    /// fonction correspondant à un DisLike, peut retourner "ok", "notlog", "error"
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    [WebMethod(enableSession: true)]
    public static string DisLike(string Id, string PoC_Ar)
    {
        string s = "notlog";
        //vérification que le user est connecté
        s = "ok";

        //ajout dans la bdd du like


        return s;
    }
}
