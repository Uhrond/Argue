﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Text;

public partial class Accueil : System.Web.UI.Page
{
    //Chargement des templates
    private static String mapPath = HttpContext.Current.Server.MapPath("~/");
    private StringBuilder Template_Header = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Header.html"));
    private StringBuilder Template_Poc = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Poc.html"));
    private StringBuilder Template_Timeline = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Timeline.html"));
    private StringBuilder Template_Trie = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Trie.html"));
    private StringBuilder Template_ArgueGauche = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueGauche.html"));
    private StringBuilder Template_ArgueDroit = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/ArgueDroit.html"));
    private StringBuilder Template_Reponse = new StringBuilder().Append(File.ReadAllText(mapPath + "/Template/Reponse.html"));

    /// <summary>
    /// Chargement de la page d'Argue
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        StringBuilder HTML = new StringBuilder();
        //Récupération de l'id de l'Argue dans l'url


        //Recherche dans la bdd du Poc

        //Construction de la page
        //Ecriture des balises meta

        //header
        HTML.Append(Template_Header.ToString());

        //Poc
        HTML.Append(Template_Poc.ToString());

        HTML.Replace("@Auteur@", "Moi");
        HTML.Replace("@DatePublication@", "15/10/2016");
        HTML.Replace("@TitreCourt@", "le carotage.");
        HTML.Replace("@Description@", "Description du Poc");
        HTML.Replace("@PcPour@", "30");

        //Ajout à la page
        Html_1.Text = HTML.ToString();
        HTML.Clear();

        //timeline
        HTML.Append(Template_Timeline.ToString());
        HTML.Replace("@height@", "1000");

        //trie
        HTML.Append(Template_Trie.ToString());

        //argue gauche 
        HTML.Append(Template_ArgueGauche.ToString());

        HTML.Replace("@Top@", "0");
        HTML.Replace("@IdArgue@", "1");
        HTML.Replace("@DatePublication@", "15/10/2016");
        HTML.Replace("@Pertinence@", "1");
        HTML.Replace("@Auteur@", "Moi");
        HTML.Replace("@Text@", "bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla ");
        HTML.Replace("@NbReport@", "10");
        HTML.Replace("@NbLike@", "50");
        HTML.Replace("@NbReponse@", "5");
        HTML.Replace("@Reponses@", "");


        //argue gauche 
        HTML.Append(Template_ArgueGauche.ToString());

        HTML.Replace("@Top@", "300");
        HTML.Replace("@IdArgue@", "2");
        HTML.Replace("@DatePublication@", "15/10/2016");
        HTML.Replace("@Pertinence@", "1");
        HTML.Replace("@Auteur@", "Moi");
        HTML.Replace("@Text@", "bla bla bla bla bla bla bla bla bla bla ");
        HTML.Replace("@NbReport@", "10");
        HTML.Replace("@NbLike@", "50");
        HTML.Replace("@NbReponse@", "5");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++)
        {
            sb.Append(sb.ToString() + Template_Reponse.ToString());
            sb.Replace("@DatePublication@", "15/10/2016");
            sb.Replace("@Auteur@", "Savi");
            sb.Replace("@Text@", "blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo blo ");
        }
        HTML.Replace("@Reponses@", sb.ToString());

        //argue droit 
        HTML.Append(Template_ArgueDroit.ToString());

        HTML.Replace("@Top@", "100");
        HTML.Replace("@IdArgue@", "1");
        HTML.Replace("@DatePublication@", "15/10/2016");
        HTML.Replace("@Pertinence@", "1");
        HTML.Replace("@Auteur@", "Moi");
        HTML.Replace("@Text@", "bla bla bla bla bla bla bla bla bla bla ");
        HTML.Replace("@NbReport@", "10");
        HTML.Replace("@NbLike@", "50");
        HTML.Replace("@NbReponse@", "5");
        HTML.Replace("@Reponses@", "");

        //footer


        //Ajout à la page
        Html_2.Text = HTML.ToString();

    }
}