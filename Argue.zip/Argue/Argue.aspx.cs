﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Accueil : System.Web.UI.Page
{
    /// <summary>
    /// Chargement de la page d'Argue
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        ///Récupération de l'id de l'Argue dans l'url
        




        ///Recherche dans la bdd du PoC

        ArgueOBJ a = new ArgueOBJ();
        //a.PoC = false;
        //a.Content = "dsferjgnegnjke<br/><br/><br/><br/><br/><br/><br/>kljnnk<br/><br/><br/><br/>hkjhkjh";
        //a.VoteContre = 10;
        //a.VotePour = 5;
        //a.NbRep = 25;
        //ArgueUI argue = new ArgueUI(a);
        //Lit.Text = argue.Str.ToString();
        //a.PoC = true;
        //argue = new ArgueUI(a);
        //Lit.Text += argue.Str.ToString();
        //a.PoC = true;
        //argue = new ArgueUI(a);
        //Lit.Text += argue.Str.ToString();
        //a.PoC = false;
        //argue = new ArgueUI(a);
        //Lit.Text += argue.Str.ToString();

    }
}