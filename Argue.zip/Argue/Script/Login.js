﻿/* fonction d'affichage du login */
function Login() {
    $("body").append("<div class='BackgroundLogin'></div>");
    $("body").append("<div class='BackgroundLoginPos'></div>");

    $(".LoginContainer").detach().appendTo('.BackgroundLoginPos');
    $(".LoginContainer").css('visibility', 'visible').stop().fadeIn();
}

/* Au click à l'exterieur de la div de login, on la masque */
$(document).mouseup(function (e) {
    var container = $(".LoginContainer");
    if (!container.is(e.target) && container.has(e.target).length === 0)
        HideLogin();
});

function HideLogin() { 
    $(".LoginContainer").stop().fadeOut(function () {
        $(".LoginContainer").detach().appendTo('body');
        $(".LoginContainer").css('visibility', 'hidden');
        $(".BackgroundLogin, .BackgroundLoginPos").remove();
    })
}