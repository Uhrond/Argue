﻿/* fonction d'affichage du login */
function Login(val) {

    $("body").append("<div class='BackgroundLogin'></div>");
    $("body").append("<div class='BackgroundLoginPos'></div>");

    $(".LoginContainer").detach().appendTo('.BackgroundLoginPos');
    if (val == "Connexion") {
        $(".Inscription").hide();
        $(".Connexion").show();
    }
    else {
        $(".Connexion").hide();
        $(".Inscription").show();
    }
    $(".LoginContainer").css('visibility', 'visible').stop().fadeIn();
}

/* Au click à l'exterieur de la div de login, on la masque */
$(document).mouseup(function (e) {
    var container = $(".LoginContainer");
    if (!container.is(e.target) && container.has(e.target).length === 0)
        HideLogin();
});

function HideLogin() {
    $(".LoginContainer").stop().fadeOut(function () {
        $(".LoginContainer").detach().appendTo('body');
        $(".LoginContainer").css('visibility', 'hidden');
        $(".BackgroundLogin, .BackgroundLoginPos").remove();
    });
}
/* Close de la fenêtre */
$(".close").click(function () {
    HideLogin();
});

/* Click sur connexion ou inscription du header */
$(".LogIn").click(function () {
    Login("Connexion");
});
$(".SignIn").click(function () {
    Login("Inscription");
});

/* switch entre conexion et inscription */
$(".SwitchInscription").click(function () {
    $(".Connexion").hide();
    $(".Inscription").show();
});
$(".SwitchConnexion").click(function () {
    $(".Inscription").hide();
    $(".Connexion").show();
});

/* Déconnexion */
$(".HeaderDeco").click(function () {
    $.ajax({
        url: "Argue.aspx/Disconnect",
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            if(data.d)
                window.location.reload();
        },
        error: function error(data) {
            Error();
        }
    });
});


/* Vérifier la saisie de l'utilisateur */
