﻿/* Variable */
var Title = "";
/* Gestion du header on scroll */
$(document).scroll(function () {
    var $item = $(".Main_title, .PoC_title");
    if ($(document).scrollTop() > 100 && Title == "") {
        Title = $item.html();
        $item.fadeOut(500, function () {
            $item.html($(".Title_PoC").html());
            $item.removeClass("Main_title");
            $item.addClass("PoC_title");
            $item.fadeIn(500);
        });
    }
    else if ($(document).scrollTop() <= 100 && Title != "") {
        Title = "";
        $item.fadeOut(500, function () {
            $item.html("Argue");
            $item.removeClass("PoC_title");
            $item.addClass("Main_title");
            $item.fadeIn(500);
        });
    }
});



/* Gestion des boutons share au scroll */
$(document).scroll(function () {
    var $item = $(".Container_Share");
    if ($(document).scrollTop() > 50) {
        $item.stop().animate({
            left: "-50px"
        }, 200);
    }
    else if ($(document).scrollTop() <= 100) {
        $item.stop().animate({
            left: "60px"
        }, 200);
    }
});
$(".Container_Share").mouseenter(function () {
    if ($(this).position().left < 0) {
        $(this).stop().animate({
            left: "0"
        }, 200);
    }
});
$(".Container_Share").mouseleave(function () {
    if ($(this).position().left == 0) {
        $(this).stop().animate({
            left: "-50px"
        }, 200);
    }
});



/* Resize de la page */
$(window).resize(function () {
    waitForFinalEvent(function () {
        Disposition();
    }, 500, "Id1");
});