/* Gestion de la position top des argues */
function Disposition()
{
    var topLeft = 20;
    var topRight = 20;
    $(".Right_Ar, .Left_Ar").sort(function (A, B)
    {
        var likeA = $(A).data("like");
        var likeB = $(B).data("like");
        return ((likeA > likeB) ? -1 : ((likeA < likeB) ? 1 : 0));
    }).each(function (index, item)
    {
        var $item = $(item);

        if ($item.hasClass("Right_Ar") && index == 0)
            topLeft = 150;
        else if ($item.hasClass("Left_Ar") && index == 0)
            topRight = 150;

        if ($item.hasClass("Right_Ar"))
        {
            $item.css('top', topRight);
            topRight += $item.height() + 150;
        }
        else if ($item.hasClass("Left_Ar"))
        {
            $item.css('top', topLeft);
            topLeft += $item.height() + 150;
        }
    });
    if (topLeft > topRight)
        $(".Container_Ar, .Timeline_Ar").height(topLeft);
    else
        $(".Container_Ar, .Timeline_Ar").height(topRight);

}
$(document).ready(function ()
{
    Disposition();
});

/* Affichage d'une page avec une anchor */
$(document).ready(function ()
{
    if (window.location.hash && $(window.location.hash).length)
    {
        $('html, body').animate({
            scrollTop: $(window.location.hash).offset().top - 100
        }, 1000);
    }
});
/* Share buttons */
$(".Container_facebook").click(function () {
    window.open('https://www.facebook.com/sharer/sharer.php?u=' + document.URL.replace(/#.*$/, ""), "Partager sur facebook", "menubar=no, status=no, scrollbars=no, menubar=no, width=0, height=0");
});
$(".Container_twitter").click(function () {
    window.open('https://twitter.com/home?status=' + document.URL.replace(/#.*$/, ""), "Partager sur facebook", "menubar=no, status=no, scrollbars=no, menubar=no, width=0, height=0");
});
$(".Container_google").click(function () {
    window.open('https://plus.google.com/share?url=' + document.URL.replace(/#.*$/, ""), "Partager sur facebook", "menubar=no, status=no, scrollbars=no, menubar=no, width=0, height=0");
});
$(".Container_gmail").click(function () {
    window.open('https://mail.google.com/mail/?view=cm&fs=1&to=&su=' + $(".Title_PoC").html() + '&body=' + document.URL.replace(/#.*$/, ""));
});




/* POST Ajax pour récup les items liker/disliker du user si connecté */
function LikeDislike() {

    var Id_PoC = $(".Container_PoC").attr("id").replace("PoC_", "");

    var data = "{'Id_PoC':'" + Id_PoC + "'}";
    $.ajax({
        url: "Argue.aspx/LikeDislike",
        data: data,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            var object = JSON.parse(data.d);
            for (var ppt in object) {
                if (ppt.substring(0, ppt.indexOf("_")) == "PoC") {
                    var s = object[ppt];
                    if (s == -1) {
                        $("#" + ppt).find(".FooterLike_PoC").removeClass("FooterLike_PoC").addClass("FooterLikeSelect_PoC");
                        $("#" + ppt).find(".FooterLikeImg_PoC").removeClass("FooterLikeImg_PoC").addClass("FooterLikeImgSelect_PoC");
                    }
                    else {
                        $("#" + ppt).find(".FooterLikeSelect_PoC").removeClass("FooterLikeSelect_PoC").addClass("FooterLike_PoC");
                        $("#" + ppt).find(".FooterLikeImgSelect_PoC").removeClass("FooterLikeImgSelect_PoC").addClass("FooterLikeImg_PoC");
                    }
                }
                if (ppt.substring(0, ppt.indexOf("_")) == "Argue") {
                    var s = object[ppt];
                    if (s == -1) {
                        $("#" + ppt).find(".FooterLike_Ar").removeClass("FooterLike_Ar").addClass("FooterLikeSelect_Ar");
                        $("#" + ppt).find(".FooterLikeImg_Ar").removeClass("FooterLikeImg_Ar").addClass("FooterLikeImgSelect_Ar");
                    }
                    else {
                        $("#" + ppt).find(".FooterLikeSelect_Ar").removeClass("FooterLikeSelect_Ar").addClass("FooterLike_Ar");
                        $("#" + ppt).find(".FooterLikeImgSelect_Ar").removeClass("FooterLikeImgSelect_Ar").addClass("FooterLikeImg_Ar");
                    }

                }
                if (ppt.substring(0, ppt.indexOf("_")) == "Reponse") {
                    var s = object[ppt];
                    if (s == -1) {
                        $("#" + ppt).find(".FooterLike_Reponse").removeClass("FooterLike_Reponse").addClass("FooterLikeSelect_Reponse");
                        $("#" + ppt).find(".FooterLikeImg_Reponse").removeClass("FooterLikeImg_Reponse").addClass("FooterLikeImgSelect_Reponse");
                    }
                    else {
                        $("#" + ppt).find(".FooterLikeSelect_Reponse").removeClass("FooterLikeSelect_Reponse").addClass("FooterLike_Reponse");
                        $("#" + ppt).find(".FooterLikeImgSelect_Reponse").removeClass("FooterLikeImgSelect_Reponse").addClass("FooterLikeImg_Reponse");
                    }
                }
            }
        },
        error: function error(data) {
            Error();
        }
    });
}
LikeDislike();





/* Gestion de l'affichage des réponses */
function HideReponse() {
    $(".ReponseLeft_Ar, .ReponseRight_Ar").hide();
}
HideReponse();

$(".FooterShowReply_Ar, .FooterShowReply_Ar").click(function () {
    $(this).closest(".Left_Ar, .Right_Ar").find(".ReponseLeft_Ar, .ReponseRight_Ar").toggle();
    Disposition();
});



/* Evenement des clicks sur les boutons */
/*Like*/
$(".FooterLike_PoC, .FooterLike_Ar").click(function () {
    var v = "PoC";
    if ($(this).hasClass("FooterLike_Ar") || $(this).hasClass("FooterLikeSelect_Ar"))
        v = "Ar";

    /* Récupe de l'id_PoC */
    var Id_PoC = $(this).parent().parent().attr("id").replace("PoC_", "").replace("Argue_", "");

    var data = "{'Id':'" + Id_PoC + "', 'PoC_Ar':'" + v + "'}";
    $.ajax({
        url: "Argue.aspx/Like",
        data: data,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            //si data.d="Ok" -> appel de la fonction LikeDislike()
            if (data.d == "Ok") {
                LikeDislike();
            }
            if (data.d == "Login") {
                Login("Connexion");
            }
        },
        error: function error(data) {
            Error();
        }
    });
});
/*DisLike*/
$(".FooterDisLike_PoC, .FooterDisLike_Ar").click(function () {
    var v = "PoC";
    if ($(this).hasClass("FooterDisLike_Ar"))
        v = "Ar";

    /* Récupe de l'id_PoC */
    var Id_PoC = $(this).parent().parent().attr("id").replace("PoC_", "").replace("Argue_", "");

    var data = "{'Id':'" + Id_PoC + "', 'PoC_Ar':'" + v + "'}";
    $.ajax({
        url: "Argue.aspx/DisLike",
        data: data,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            //si data.d="Ok" -> appel de la fonction LikeDislike()
            LikeDislike();

            //si data.d="notlog" -> ouverture de la page d'inscription/connexion

            //si data.d="error" -> alert error
        },
        error: function error(data) {
            //alert error
        }
    });
});
/*Link*/
$(".FooterShareLink_PoC, .FooterShareLink_Ar").click(function () {
    HideAllTooltip();

    /* creation d'une div */
    var div = "<div class='LinkTooltip' style='";
    var top = $(this).offset().top + $(this).height();
    div += "top:" + top + "px;";
    var left = $(this).offset().left + $(this).width() / 2 - 300 / 2;
    if (left < 0)
        left = 0;
    if (left + 300 > $(window).width())
        left = $(window).width() - 300;
    div += "left: " + left + "px;";
    var url;
    if ($(this).hasClass("FooterShareLink_PoC"))
        url = window.location.href.replace(/#.*$/, "");
    else
        url = window.location.href.replace(/#.*$/, "") + "#" + $(this).closest(".Left_Ar, .Right_Ar").attr('id');

    div += "'>Lien copié : <br/>" + url + "</div>";
    copyToClipboard(url);

    $('body').append(div);
    $('.LinkTooltip').hide().fadeIn(500).delay(1500).fadeOut(500);
});

/* CKEditor */
$(".FooterReply_PoC").click(function () {
    $("body").append("<div class='ckeditor'> <textarea name='edit' id='edit' rows='0' cols='0'></textarea></div>");
    CKEDITOR.replace('edit');
});
/* fonction d'affichage du login */
function Login(val) {

    $("body").append("<div class='BackgroundLogin'></div>");
    $("body").append("<div class='BackgroundLoginPos'></div>");

    $(".LoginContainer").detach().appendTo('.BackgroundLoginPos');
    if (val == "Connexion") {
        $(".Inscription").hide();
        $(".Connexion").show();
    }
    else {
        $(".Connexion").hide();
        $(".Inscription").show();
    }
    $(".LoginContainer").css('visibility', 'visible').stop().fadeIn();
}

/* Au click à l'exterieur de la div de login, on la masque */
$(document).mouseup(function (e) {
    var container = $(".LoginContainer");
    if (!container.is(e.target) && container.has(e.target).length === 0)
        HideLogin();
});

function HideLogin() {
    $(".LoginContainer").stop().fadeOut(function () {
        $(".LoginContainer").detach().appendTo('body');
        $(".LoginContainer").css('visibility', 'hidden');
        $(".BackgroundLogin, .BackgroundLoginPos").remove();
    });
}
/* Close de la fenêtre */
$(".close").click(function () {
    HideLogin();
});

/* Click sur connexion ou inscription du header */
$(".LogIn").click(function () {
    Login("Connexion");
});
$(".SignIn").click(function () {
    Login("Inscription");
});

/* switch entre conexion et inscription */
$(".SwitchInscription").click(function () {
    $(".Connexion").hide();
    $(".Inscription").show();
});
$(".SwitchConnexion").click(function () {
    $(".Inscription").hide();
    $(".Connexion").show();
});

/* Déconnexion */
$(".HeaderDeco").click(function () {
    $.ajax({
        url: "Argue.aspx/Disconnect",
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            if (data.d)
                window.location.reload();
        },
        error: function error(data) {
            Error();
        }
    });
});

/* Connexion */
$(".BtnConnexion").click(function (event) {

    /* Gérer les champs vide et longueur */

    /* envoi au serveur */
    var data = "{'Login':'" + $("#Login").val() + "', 'Password':'" + $("#Password").val() + "'}";
    $.ajax({
        url: "Argue.aspx/Connexion",
        data: data,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function success(data) {
            if (data.d == "SpecChar") {

            }
            else if (data.d == "Fail") {
                Error();
            }
            else if (data.d == "Success")
                window.location.reload();
        },
        error: function error(data) {
            Error();
        }
    });
    event.preventDefault();
});

/* Vérifier la saisie de l'utilisateur */

/*Copy to clipboard*/
function copyToClipboard(element)
{
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(element).select();
    document.execCommand("copy");
    $temp.remove();
}



/*  Tooltip  */
$('.hashtmltip').click(function ()
{
    /* On cache les autres tooltip */
    HideAllTooltip();

    var $item = $(this).parent().find(".Signaler");
    $item.css('display', 'block');
    var top = $(this).position().top + $(this).height();
    $item.css('top', top);
    var left = $(this).position().left + $(this).width() / 2 - 300 / 2;
    if (left < 0)
        left = 0;
    $item.css('left', left);
});
function HideAllTooltip()
{
    if ($('.LinkTooltip').length)
        $('.LinkTooltip').stop().fadeOut(200, function () { $(this).remove(); });

    $(".Signaler").stop().fadeOut(200, function () { $(this).css('display', 'none'); });
}
/* Au click à l'exterieur d'un div de tooltip on masque les tooltips */
$(document).mouseup(function (e)
{
    var container = $(".LinkTooltip, .Signaler");
    if (!container.is(e.target) && container.has(e.target).length === 0)
        HideAllTooltip();
});

/* Click sur le logo */
$(".Logo, .Main_title").click(function () {
    window.location.href = "Index.aspx";
});

/* attend le dernier evenement */
var waitForFinalEvent = (function ()
{
    var timers = {};
    return function (callback, ms, uniqueId)
    {
        if (!uniqueId)
        {
            uniqueId = "Don't call this twice without a uniqueId";
        }
        if (timers[uniqueId])
        {
            clearTimeout(timers[uniqueId]);
        }
        timers[uniqueId] = setTimeout(callback, ms);
    };
})();


/* Variable */
var Title = "";
/* Gestion du header on scroll */
$(document).scroll(function () {
    var $item = $(".Main_title, .PoC_title");
    if ($(document).scrollTop() > 100 && Title == "") {
        Title = $item.html();
        $item.fadeOut(500, function () {
            $item.html($(".Title_PoC").html());
            $item.removeClass("Main_title");
            $item.addClass("PoC_title");
            $item.fadeIn(500);
        });
    }
    else if ($(document).scrollTop() <= 100 && Title != "") {
        Title = "";
        $item.fadeOut(500, function () {
            $item.html("Argue");
            $item.removeClass("PoC_title");
            $item.addClass("Main_title");
            $item.fadeIn(500);
        });
    }
});



/* Gestion des boutons share au scroll */
$(document).scroll(function () {
    var $item = $(".Container_Share");
    if ($(document).scrollTop() > 50) {
        $item.stop().animate({
            left: "-50px"
        }, 200);
    }
    else if ($(document).scrollTop() <= 100) {
        $item.stop().animate({
            left: "60px"
        }, 200);
    }
});
$(".Container_Share").mouseenter(function () {
    if ($(this).position().left < 0) {
        $(this).stop().animate({
            left: "0"
        }, 200);
    }
});
$(".Container_Share").mouseleave(function () {
    if ($(this).position().left == 0) {
        $(this).stop().animate({
            left: "-50px"
        }, 200);
    }
});



/* Resize de la page */
$(window).resize(function () {
    waitForFinalEvent(function () {
        Disposition();
    }, 500, "Id1");
});