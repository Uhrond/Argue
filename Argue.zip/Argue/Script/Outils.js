﻿/*Copy to clipboard*/
function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(element).select();
    document.execCommand("copy");
    $temp.remove();
}



/*  Tooltip  */
$('.hashtmltip').click(function () {
    /* On cache les autres tooltip */
    HideAllTooltip();

    var $item = $(this).parent().find(".Signaler");
    $item.css('display', 'block');
    var top = $(this).position().top + $(this).height();
    $item.css('top', top);
    var left = $(this).position().left + $(this).width() / 2 - 300 / 2;
    if (left < 0)
        left = 0;
    $item.css('left', left);
});
function HideAllTooltip() {
    if ($('.LinkTooltip').length)
        $('.LinkTooltip').stop().fadeOut(200, function () { $(this).remove(); });

    $(".Signaler").stop().fadeOut(200, function () { $(this).css('display', 'none'); });
}
/* Au click à l'exterieur d'un div de tooltip on masque les tooltips */
$(document).mouseup(function (e) {
    var container = $(".LinkTooltip, .Signaler");
    if (!container.is(e.target) && container.has(e.target).length === 0)
        HideAllTooltip();
});


/* attend le dernier evenement */
var waitForFinalEvent = (function () {
    var timers = {};
    return function (callback, ms, uniqueId) {
        if (!uniqueId) {
            uniqueId = "Don't call this twice without a uniqueId";
        }
        if (timers[uniqueId]) {
            clearTimeout(timers[uniqueId]);
        }
        timers[uniqueId] = setTimeout(callback, ms);
    };
})();
