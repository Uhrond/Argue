﻿/* CKEditor */
$(".FooterReply_PoC").click(function () {
    $("body").append("<div class='ckeditor'> <textarea name='edit' id='edit' rows='0' cols='0'></textarea></div>");
    CKEDITOR.replace('edit');
});