﻿/* Gestion de la position top des argues */
function Disposition() {
    var topLeft = 20;
    var topRight = 20;
    $(".Right_Ar, .Left_Ar").sort(function (A, B) {
        var likeA = $(A).data("like");
        var likeB = $(B).data("like");
        return ((likeA > likeB) ? -1 : ((likeA < likeB) ? 1 : 0));
    }).each(function (index, item) {
        var $item = $(item);

        if ($item.hasClass("Right_Ar") && index == 0)
            topLeft = 150;
        else if ($item.hasClass("Left_Ar") && index == 0)
            topRight = 150;

        if ($item.hasClass("Right_Ar")) {
            $item.css('top', topRight);
            topRight += $item.height() + 150;
        }
        else if ($item.hasClass("Left_Ar")) {
            $item.css('top', topLeft);
            topLeft += $item.height() + 150;
        }
    });
    if (topLeft > topRight)
        $(".Container_Ar, .Timeline_Ar").height(topLeft);
    else
        $(".Container_Ar, .Timeline_Ar").height(topRight);

}
Disposition();


/* Affichage d'une page avec une anchor */
$(document).ready(function () {
    if (window.location.hash && $(window.location.hash).length) {
        $('html, body').animate({
            scrollTop: $(window.location.hash).offset().top - 100
        }, 1000);
    }
});