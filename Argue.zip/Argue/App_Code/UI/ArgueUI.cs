﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

/// <summary>
/// Description résumée de ArgueUI
/// </summary>
public class ArgueUI
{
    public StringBuilder Str = new StringBuilder();

    public ArgueUI(ArgueOBJ argueOBJ)
    {
        if (argueOBJ.PoC == false)
            Str.Append("<div  class='container_post_left'>");
        else
            Str.Append("<div  class='container_post_right'>");

        Str.Append("<div class='header_post'>");
        Str.Append("<div class='img_post'>");
        Str.Append("</div>");
        Str.Append("<div class='header_text_post'>");

        Str.Append("Posté par ");
        Str.Append(", Le ");
        
        Str.Append("</div>");
        Str.Append("</div>");
        Str.Append("<div class='content_post' data-height=''>");
        Str.Append(argueOBJ.Content);
        Str.Append("</div>");
        Str.Append("<div class='footer_post'>");
        Str.Append("<input type='image' src='Ressources/point_exc.svg' alt='Signaler' class='icon report hashtmltip'>");
        Str.Append("<div style='display: inline;'>");
        Str.Append("<div class='Signaler' style='display: none;'>");
        Str.Append("Signaler un contenu inapproprié :");
        Str.Append("</div>");
        Str.Append("</div>");

        Str.Append("<span class='reportNb' - >");
        Str.Append(argueOBJ.VoteContre.ToString());
        Str.Append("</span>");

        Str.Append("<input type = 'image'  src='Ressources/like.svg' alt='Like' class='icon like hastip' title='Approuver'>");
        Str.Append("<span class='likeNb'> - ");
        Str.Append(argueOBJ.VotePour.ToString());
        Str.Append("</span>");

        Str.Append("<input type = 'image'  src='Ressources/dbArrowDown.svg' alt='ReadMore' class='icon readmore hastip hidden' title='Lire la suite'>");
        Str.Append("<input type = 'image'  src='Ressources/repondre.svg' alt='Répondre' class='icon answer hastip' title='Répondre'>");
        Str.Append("<span class='answerNb'> - ");
        Str.Append(argueOBJ.NbRep.ToString());
        Str.Append("</span>");

        Str.Append("</div>");
        Str.Append("</div>");
    }
}