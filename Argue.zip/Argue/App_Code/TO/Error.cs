﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Error
/// </summary>
public class Error
{
    public Error(Exception e)
    {
    }
    public Error(String e)
    {

    }
}