﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;
using System.Reflection;
using System.Collections.Generic;

/// <summary>
/// 09/09/2015 Par Savinien Taillefert
/// Classe de connexion à une base SQL et execution de procédures stockées
/// </summary>
public class DataConnection
{
    private SqlConnection _Con = null;
    private SqlTransaction _Trans = null;
    private Boolean _IsError = false;
    private String _MessageErreur = "";
    private String _Type = "PROC";

    public DataConnection(String ConnectionString)
    {
        try
        {
            _Con = new SqlConnection(ConnectionString);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    /// <summary>
    /// Requête retournant une liste de données
    /// </summary>
    public void request(String StoredProcedure, ref DataTable dt)
    {
        ParametersList param = new ParametersList();
        try
        {
            dt = ExecuteRequest(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref DataTable dt)
    {
        try
        {
            dt = ExecuteRequest(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ref List<String> lst, String Column)
    {
        ParametersList param = new ParametersList();
        DataTable dt = new DataTable();
        try
        {
            dt = ExecuteRequest(StoredProcedure, param);
            foreach (DataRow dr in dt.Rows)
                lst.Add(dr[Column].ToString());
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref List<String> lst, String Column)
    {
        DataTable dt = new DataTable();
        try
        {
            dt = ExecuteRequest(StoredProcedure, param);
            foreach (DataRow dr in dt.Rows)
                lst.Add(dr[Column].ToString());
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    private DataTable ExecuteRequest(String StoredProcedure, ParametersList param)
    {
        ConOpen();
        SqlTransaction _TransInterne = null;
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand(StoredProcedure, _Con);
            if (_Type == "SQL")
            {
                cmd.CommandType = CommandType.Text;
                _Type = "PROC";
            }
            else
                cmd.CommandType = CommandType.StoredProcedure;
            if (_Trans == null)
            {
                _TransInterne = _Con.BeginTransaction();
                cmd.Transaction = _TransInterne;
            }
            else
                cmd.Transaction = _Trans;
            //Parametres
            foreach (KeyValuePair<String, Object> KeyValuePair in param)
                cmd.Parameters.AddWithValue(KeyValuePair.Key, KeyValuePair.Value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (_Trans == null)
                _TransInterne.Commit();
        }
        catch (Exception ex)
        {
            if (_Trans == null)
                _TransInterne.Rollback();
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
        finally
        {
            if (_Trans == null)
                ConClose();
        }

        return dt;
    }

    /// <summary>
    /// Requête retournant une seule donnée
    /// </summary>
    public void request(String StoredProcedure, ref Object obj)
    {
        ParametersList param = new ParametersList();
        try
        {
            obj = ExecuteScalar(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref Object obj)
    {
        try
        {
            obj = ExecuteScalar(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ref String str)
    {
        ParametersList param = new ParametersList();
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            if (obj != null)
                str = obj.ToString();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref String str)
    {
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            if (obj != null)
                str = obj.ToString();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ref Int32 nb)
    {
        ParametersList param = new ParametersList();
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Int32 _test;
            if (obj != null && Int32.TryParse(obj.ToString(), out _test))
                nb = Convert.ToInt32(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }

    }
    public void request(String StoredProcedure, ParametersList param, ref Int32 nb)
    {
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Int32 _test;
            if (obj != null && Int32.TryParse(obj.ToString(), out _test))
                nb = Convert.ToInt32(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }

    }
    public void request(String StoredProcedure, ref Double nb)
    {
        ParametersList param = new ParametersList();
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Double _test;
            if (obj != null && Double.TryParse(obj.ToString(), out _test))
                nb = Convert.ToDouble(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref Double nb)
    {
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Double _test;
            if (obj != null && Double.TryParse(obj.ToString(), out _test))
                nb = Convert.ToDouble(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ref Boolean b)
    {
        ParametersList param = new ParametersList();
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Boolean _test;
            if (obj != null && Boolean.TryParse(obj.ToString(), out _test))
                b = Convert.ToBoolean(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref Boolean b)
    {
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            Boolean _test;
            if (obj != null)
            {
                if (Boolean.TryParse(obj.ToString(), out _test))
                    b = Convert.ToBoolean(obj);
                else if (obj.ToString() == "1")
                    b = true;
                else if (obj.ToString() == "0" || obj.ToString() == "-1")
                    b = false;
            }
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ref DateTime date)
    {
        ParametersList param = new ParametersList();
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            DateTime _test;
            if (obj != null && DateTime.TryParse(obj.ToString(), out _test))
                date = Convert.ToDateTime(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void request(String StoredProcedure, ParametersList param, ref DateTime date)
    {
        try
        {
            Object obj = ExecuteScalar(StoredProcedure, param);
            DateTime _test;
            if (obj != null && DateTime.TryParse(obj.ToString(), out _test))
                date = Convert.ToDateTime(obj);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    private Object ExecuteScalar(String StoredProcedure, ParametersList param)
    {
        ConOpen();
        SqlTransaction _TransInterne = null;
        Object obj = new Object();
        try
        {
            SqlCommand cmd = new SqlCommand(StoredProcedure, _Con);
            if (_Type == "SQL")
            {
                cmd.CommandType = CommandType.Text;
                _Type = "PROC";
            }
            else
                cmd.CommandType = CommandType.StoredProcedure;
            if (_Trans == null)
            {
                _TransInterne = _Con.BeginTransaction();
                cmd.Transaction = _TransInterne;
            }
            else
                cmd.Transaction = _Trans;
            //Parametres
            foreach (KeyValuePair<String, Object> KeyValuePair in param)
                cmd.Parameters.AddWithValue(KeyValuePair.Key, KeyValuePair.Value);
            obj = cmd.ExecuteScalar();

            if (_Trans == null)
                _TransInterne.Commit();
        }
        catch (Exception ex)
        {
            if (_Trans == null)
                _TransInterne.Rollback();
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
        finally
        {
            if (_Trans == null)
                ConClose();
        }
        return obj;
    }

    /// <summary>
    /// Requête NonQuery
    /// </summary>

    public void Update(String StoredProcedure, ParametersList param)
    {
        try
        {
            ExecuteNonQuery(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void Insert(String StoredProcedure, ParametersList param)
    {
        try
        {
            ExecuteNonQuery(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void Delete(String StoredProcedure, ParametersList param)
    {
        try
        {
            ExecuteNonQuery(StoredProcedure, param);
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    private void ExecuteNonQuery(String StoredProcedure, ParametersList param)
    {
        ConOpen();
        SqlTransaction _TransInterne = null;
        try
        {
            SqlCommand cmd = new SqlCommand(StoredProcedure, _Con);
            if (_Type == "SQL")
            {
                cmd.CommandType = CommandType.Text;
                _Type = "PROC";
            }
            else
                cmd.CommandType = CommandType.StoredProcedure;
            if (_Trans == null)
            {
                _TransInterne = _Con.BeginTransaction();
                cmd.Transaction = _TransInterne;
            }
            else
                cmd.Transaction = _Trans;
            //Parametres
            foreach (KeyValuePair<String, Object> KeyValuePair in param)
                cmd.Parameters.AddWithValue(KeyValuePair.Key, KeyValuePair.Value);
            cmd.ExecuteNonQuery();

            if (_Trans == null)
                _TransInterne.Commit();
        }
        catch (Exception ex)
        {
            if (_Trans == null)
                _TransInterne.Rollback();
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
        finally
        {
            if (_Trans == null)
                ConClose();
        }
    }

    /// <summary>
    /// Transactionnel
    /// </summary>
    public void BeginTransaction()
    {
        try
        {
            ConOpen();
            _Trans = _Con.BeginTransaction();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void CommitTransaction()
    {
        try
        {
            _Trans.Commit();
            ConClose();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    public void Rollback()
    {
        try
        {
            _Trans.Rollback();
            ConClose();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    private void ConOpen()
    {
        try
        {
            if (_Con != null && _Con.State != ConnectionState.Open)
                _Con.Open();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }
    private void ConClose()
    {
        try
        {
            if (_Con != null && _Con.State != ConnectionState.Closed)
                _Con.Close();
        }
        catch (Exception ex)
        {
            _Con = null;
            _IsError = true;
            _MessageErreur = "Une erreur s'est produite dans " + MethodBase.GetCurrentMethod().Name + " Message : " + ex.Message;
        }
    }

    public Boolean IsError
    {
        get { return _IsError; }
    }
    public String MessageErreur
    {
        get { return _MessageErreur; }
    }
    public String Type
    {
        get { return _Type; }
        set { _Type = value; }
    }
}
/// <summary>
/// Classe de parametres (Key, Value)
/// </summary>
public class ParametersList : Dictionary<String, Object>
{
}
