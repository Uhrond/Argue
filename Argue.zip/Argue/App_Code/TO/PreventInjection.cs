﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

/// <summary>
/// Regroup des fonctions qui vérifient le texte saisi pas l'utilisateur
/// </summary>
public class PreventInjection
{
    public PreventInjection() {  }

    public bool Verif(string text)
    {
        /* caractère spéciaux */
        Regex regex = new Regex(@"[a-zA-Z0-9ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ_\-\s]*$");
        Match match = regex.Match(text);
        if (match.Success)
            return false;
        
        return true;
    }
}