﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Regroup des fonctions qui vérifient le texte saisi pas l'utilisateur
/// </summary>
public class PreventInjection
{
    public PreventInjection() {  }
}