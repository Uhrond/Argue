﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de PasswordDAO
/// </summary>
public class PasswordDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public PasswordDAO() { }

    //Insert hash password in bdd


    //compare hash password

}