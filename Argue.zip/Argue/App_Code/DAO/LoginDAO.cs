﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de LoginDAO
/// </summary>
public class LoginDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);
    private UserDAO userDAO = new UserDAO();
    private Password password = new Password();
    public LoginDAO()
    {
    }

    public UserOBJ Connexion(string Login, string Mdp)
    {
        UserOBJ userOBJ = new UserOBJ();
        int idUser = -1;

        /* Encryption du password */
        Mdp = password.HashPassword(Mdp);

        try
        {
            ParametersList param_connexion = new ParametersList();
            param_connexion.Add("Login", Login);
            param_connexion.Add("Password", Mdp);

            data.request("Get_Connexion", param_connexion, ref idUser);

            if (data.IsError)
                new Error(data.MessageErreur);

            if (idUser == -1)
                return null;
            else
                userOBJ = userDAO.Get_User(idUser);

        }
        catch (Exception e)
        {
            new Error(e);
        }

        return userOBJ;
    }
}