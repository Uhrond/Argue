﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ReponseDAO
/// </summary>
public class ReponseDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public ReponseDAO() { }

    public ReponseOBJ Get_Reponse(int Id_Reponse)
    {
        ReponseOBJ Reponse = new ReponseOBJ();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_Reponse = new ParametersList();
            param_Reponse.Add("Id_Reponse", Id_Reponse);

            data.request("Get_Reponse", param_Reponse, ref dt);

            Reponse.Id = Id_Reponse;
            Reponse.Id_Argue = Convert.ToInt32(dt.Rows[0]["Id_Argue"]);
            Reponse.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
            Reponse.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
            Reponse.Content = dt.Rows[0]["Content"].ToString();

        }
        catch (Exception e)
        {
            new Error(e);
        }
        return Reponse;
    }


    public List<ReponseOBJ> Get_LstReponse(int Id_Argue)
    {
        List<ReponseOBJ> LstReponse = new List<ReponseOBJ>();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_LstReponse = new ParametersList();
            param_LstReponse.Add("Id_PoC", Id_Argue);

            data.request("Get_LstReponse", param_LstReponse, ref dt);
            foreach (DataRow dr in dt.Rows)
            {
                LstReponse.Add(new ReponseDAO().Get_Reponse(Convert.ToInt32(dr["Id_Reponse"])));
            }
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return LstReponse;
    }



}