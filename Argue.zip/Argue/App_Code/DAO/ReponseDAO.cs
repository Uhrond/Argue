﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ReponseDAO
/// </summary>
public class ReponseDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public ReponseDAO() { }

    public ReponseOBJ Get_Reponse(int Id_Reponse)
    {
        ReponseOBJ Reponse = new ReponseOBJ();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_Reponse = new ParametersList();
            param_Reponse.Add("Id_Reponse", Id_Reponse);

            data.request("Get_Reponse", param_Reponse, ref dt);

            Reponse.Id = Id_Reponse;
            Reponse.Id_Argue = Convert.ToInt32(dt.Rows[0]["Id_Argue"]);
            Reponse.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
            Reponse.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
            Reponse.Content = dt.Rows[0]["Content"].ToString();

        }
        catch (Exception e)
        {
            new Error(e);
        }

        /* No Bdd */
        //Reponse.Id = Id_Reponse;
        //Reponse.Id_Argue = 1;
        //Reponse.User = new UserDAO().Get_User(1);
        //Reponse.DateCreation = Convert.ToDateTime("10/12/2016");
        //Reponse.Content = "orem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate ac tortor ut vulputate. Proin nisl elit, sodales id venenatis at, placerat id arcu. Maecenas imperdiet, mauris quis fermentum lacinia, enim diam condimentum mi, nec convallis felis diam ut leo. Mauris auctor vel arcu nec efficitur. Fusce sollicitudin risus in mauris finibus, sit amet lobortis turpis tristique. In ac venenatis lorem, at tempus quam. Vestibulum mauris velit, varius a nunc id, finibus pharetra orci. Nulla dignissim, ligula quis egestas tempus, nisl tellus ultrices justo, et commodo quam sem dictum leo. Vestibulum lobortis tellus egestas, dapibus urna in, vehicula metus. Donec gravida, ligula quis aliquam dignissim, ipsum diam scelerisque diam, eu malesuada sapien est quis tellus. Fusce cursus ultricies porttitor. Integer condimentum, lacus at placerat sodales, arcu est porta elit, in euismod nibh velit ut est. Nam aliquam dui id felis dapibus dictum. In hac habitasse platea dictumst. Duis sit amet orci ultrices, lobortis odio nec, pulvinar ante. Cras non neque pellentesque, dapibus velit quis, ultrices ipsum. ";

        return Reponse;
    }


    public List<ReponseOBJ> Get_LstReponse(int Id_Argue)
    {
        List<ReponseOBJ> LstReponse = new List<ReponseOBJ>();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_LstReponse = new ParametersList();
            param_LstReponse.Add("Id_PoC", Id_Argue);

            data.request("Get_LstReponse", param_LstReponse, ref dt);
            foreach (DataRow dr in dt.Rows)
            {
                LstReponse.Add(new ReponseDAO().Get_Reponse(Convert.ToInt32(dr["Id_Reponse"])));
            }
        }
        catch (Exception e)
        {
            new Error(e);
        }

        /* No Bdd */
        //LstReponse.Add(new ReponseDAO().Get_Reponse(1));

        return LstReponse;
    }



}