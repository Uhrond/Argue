﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ReponseDAO
/// </summary>
public class ReponseDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public ReponseDAO() { }

    public ReponseOBJ Get_Reponse(int Id_Reponse)
    {
        ReponseOBJ Reponse = new ReponseOBJ();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_Reponse = new ParametersList();
                param_Reponse.Add("Id_Reponse", Id_Reponse);

                data.request("Get_Reponse", param_Reponse, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                Reponse.Id = Id_Reponse;
                Reponse.Id_Argue = Convert.ToInt32(dt.Rows[0]["Id_Argue"]);
                Reponse.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
                Reponse.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
                Reponse.Content = dt.Rows[0]["Content"].ToString();

            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            /* No Bdd */
            Reponse.Id = Id_Reponse;
            Reponse.Id_Argue = 1;
            Reponse.User = new UserDAO().Get_User(1);
            Reponse.DateCreation = Convert.ToDateTime("10/12/2016");
            Reponse.Content = "orem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate ac tortor ut vulputate. Proin nisl elit, sodales id venenatis at, placerat id arcu. Maecenas imperdiet, mauris quis fermentum lacinia, enim diam condimentum mi, nec convallis felis diam ut leo. Mauris auctor vel arcu nec efficitur. Fusce sollicitudin risus in mauris finibus, sit amet lobortis turpis tristique. In ac venenatis lorem, at tempus quam. Vestibulum mauris velit, varius a nunc id, finibus pharetra orci. Nulla dignissim, ligula quis egestas tempus, nisl tellus ultrices justo, et commodo quam sem dictum leo. Vestibulum lobortis tellus egestas, dapibus urna in, vehicula metus. Donec gravida, ligula quis aliquam dignissim, ipsum diam scelerisque diam, eu malesuada sapien est quis tellus. Fusce cursus ultricies porttitor. Integer condimentum, lacus at placerat sodales, arcu est porta elit, in euismod nibh velit ut est. Nam aliquam dui id felis dapibus dictum. In hac habitasse platea dictumst. Duis sit amet orci ultrices, lobortis odio nec, pulvinar ante. Cras non neque pellentesque, dapibus velit quis, ultrices ipsum. ";
        }
        return Reponse;
    }

    public List<ReponseOBJ> Get_LstReponse(int Id_Argue)
    {
        List<ReponseOBJ> LstReponse = new List<ReponseOBJ>();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_LstReponse = new ParametersList();
                param_LstReponse.Add("Id_Argue", Id_Argue);

                data.request("Get_LstReponse", param_LstReponse, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                foreach (DataRow dr in dt.Rows)
                {
                    LstReponse.Add(new ReponseDAO().Get_Reponse(Convert.ToInt32(dr["Id_Reponse"])));
                }
            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            /* No Bdd */
            LstReponse.Add(new ReponseDAO().Get_Reponse(1));
        }

        return LstReponse;
    }


    public List<int> Get_Dislike_Reponse(int Id_Reponse, int Id_User)
    {
        DataTable dt = new DataTable();
        List<int> lst = new List<int>();
        try
        {
            ParametersList param_Dislike_Reponse = new ParametersList();
            param_Dislike_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Dislike_Reponse.Add("Id_User", Id_User);

            data.request("Get_Dislike_Reponse", param_Dislike_Reponse, ref dt);

            if (data.IsError)
                new Error(data.MessageErreur);

            foreach (DataRow dr in dt.Rows)
                lst.Add(Convert.ToInt32(dr["Id_Crit"]));
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return lst;
    }

    public Boolean Get_Like_Reponse(int Id_Reponse, int Id_User)
    {
        int IsLike = -1;
        try
        {
            ParametersList param_Like_Reponse = new ParametersList();
            param_Like_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Like_Reponse.Add("Id_User", Id_User);

            data.request("Get_Like_Reponse", param_Like_Reponse, ref IsLike);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
        if (IsLike <= 0)
            return false;
        else
            return true;
    }

    public void Insert_Like_Reponse(int Id_Reponse, int Id_User)
    {
        try
        {
            ParametersList param_Like_Reponse = new ParametersList();
            param_Like_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Like_Reponse.Add("Id_User", Id_User);

            data.Insert("Insert_Like_Reponse", param_Like_Reponse);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Insert_Dislike_Reponse(int Id_Reponse, int Id_User)
    {
        try
        {
            ParametersList param_Dislike_Reponse = new ParametersList();
            param_Dislike_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Dislike_Reponse.Add("Id_User", Id_User);

            data.Insert("Insert_Dislike_Reponse", param_Dislike_Reponse);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Dislike_Reponse(int Id_Reponse, int Id_User, int Id_Crit)
    {
        try
        {
            ParametersList param_Dislike_Reponse = new ParametersList();
            param_Dislike_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Dislike_Reponse.Add("Id_User", Id_User);
            param_Dislike_Reponse.Add("Id_Crit", Id_Crit);

            data.Delete("Delete_Dislike_Reponse", param_Dislike_Reponse);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Like_Reponse(int Id_Reponse, int Id_User)
    {
        try
        {
            ParametersList param_Like_Reponse = new ParametersList();
            param_Like_Reponse.Add("Id_Reponse", Id_Reponse);
            param_Like_Reponse.Add("Id_User", Id_User);

            data.Delete("Delete_Like_Reponse", param_Like_Reponse);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
    }


}