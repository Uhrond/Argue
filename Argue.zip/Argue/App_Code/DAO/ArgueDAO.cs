﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ArgueDAO
/// </summary>
public class ArgueDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);
    public ArgueDAO() { }

    public ArgueOBJ Get_Argue(int Id_Argue)
    {
        ArgueOBJ Argue = new ArgueOBJ();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_Argue = new ParametersList();
                param_Argue.Add("Id_Argue", Id_Argue);

                data.request("Get_Argue", param_Argue, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                Argue.Id = Id_Argue;
                Argue.Id_PoC = Convert.ToInt32(dt.Rows[0]["Id_PoC"]);
                Argue.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
                Argue.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
                Argue.PoC = Convert.ToBoolean(dt.Rows[0]["PoC"]);
                Argue.Content = dt.Rows[0]["Content"].ToString();
                Argue.NbReponse = Convert.ToInt32(dt.Rows[0]["NbReponse"]);
                Argue.NbLike = Convert.ToInt32(dt.Rows[0]["NbLike"]);
                Argue.NbDisLike = Convert.ToInt32(dt.Rows[0]["NbDisLike"]);
            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            Argue.Id = Id_Argue;
            Argue.Id_PoC = 1;
            Argue.User = new UserDAO().Get_User(1);
            Argue.DateCreation = Convert.ToDateTime("08/11/2016");
            Random rand = new Random();
            System.Threading.Thread.Sleep(5);
            Argue.PoC = Convert.ToBoolean(rand.Next() % 2);
            Argue.Content = "orem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate ac tortor ut vulputate. Proin nisl elit, sodales id venenatis at, placerat id arcu. Maecenas imperdiet, mauris quis fermentum lacinia, enim diam condimentum mi, nec convallis felis diam ut leo. Mauris auctor vel arcu nec efficitur. Fusce sollicitudin risus in mauris finibus, sit amet lobortis turpis tristique. In ac venenatis lorem, at tempus quam. Vestibulum mauris velit, varius a nunc id, finibus pharetra orci. Nulla dignissim, ligula quis egestas tempus, nisl tellus ultrices justo, et commodo quam sem dictum leo. Vestibulum lobortis tellus egestas, dapibus urna in, vehicula metus. Donec gravida, ligula quis aliquam dignissim, ipsum diam scelerisque diam, eu malesuada sapien est quis tellus. Fusce cursus ultricies porttitor. Integer condimentum, lacus at placerat sodales, arcu est porta elit, in euismod nibh velit ut est. Nam aliquam dui id felis dapibus dictum. In hac habitasse platea dictumst. Duis sit amet orci ultrices, lobortis odio nec, pulvinar ante. Cras non neque pellentesque, dapibus velit quis, ultrices ipsum. ";
            Argue.NbReponse = 1;
            Argue.NbLike = 5;
            Argue.NbDisLike = 2;
        }

        return Argue;
    }

    /// <summary>
    /// Remonte la liste des Argues relatif à un PoC
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    public List<ArgueOBJ> Get_ListArgue(int Id_PoC)
    {
        List<ArgueOBJ> LstArgue = new List<ArgueOBJ>();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_LstArgue = new ParametersList();
                param_LstArgue.Add("Id_PoC", Id_PoC);

                data.request("Get_LstArgue", param_LstArgue, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                foreach (DataRow dr in dt.Rows)
                {
                    LstArgue.Add(new ArgueDAO().Get_Argue(Convert.ToInt32(dr["Id_Argue"])));
                }
            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            /* No Bdd */
            LstArgue.Add(new ArgueDAO().Get_Argue(1));
            LstArgue.Add(new ArgueDAO().Get_Argue(2));
            LstArgue.Add(new ArgueDAO().Get_Argue(3));
            LstArgue.Add(new ArgueDAO().Get_Argue(4));
            LstArgue.Add(new ArgueDAO().Get_Argue(5));
            LstArgue.Add(new ArgueDAO().Get_Argue(6));
        }

        return LstArgue;
    }


    public List<int> Get_Dislike_Argue(int Id_Argue, int Id_User)
    {
        DataTable dt = new DataTable();
        List<int> lst = new List<int>();
        try
        {
            ParametersList param_Dislike_Argue = new ParametersList();
            param_Dislike_Argue.Add("Id_Argue", Id_Argue);
            param_Dislike_Argue.Add("Id_User", Id_User);

            data.request("Get_Dislike_Argue", param_Dislike_Argue, ref dt);

            if (data.IsError)
                new Error(data.MessageErreur);

            foreach (DataRow dr in dt.Rows)
                lst.Add(Convert.ToInt32(dr["Id_Crit"]));
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return lst;
    }

    public Boolean Get_Like_Argue(int Id_Argue, int Id_User)
    {
        int IsLike = -1;
        try
        {
            ParametersList param_Like_Argue = new ParametersList();
            param_Like_Argue.Add("Id_Argue", Id_Argue);
            param_Like_Argue.Add("Id_User", Id_User);

            data.request("Get_Like_Argue", param_Like_Argue, ref IsLike);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
        if (IsLike <= 0)
            return false;
        else
            return true;
    }

    public void Insert_Like_Argue(int Id_Argue, int Id_User)
    {
        try
        {
            ParametersList param_Like_Argue = new ParametersList();
            param_Like_Argue.Add("Id_Argue", Id_Argue);
            param_Like_Argue.Add("Id_User", Id_User);

            data.Insert("Insert_Like_Argue", param_Like_Argue);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Insert_Dislike_Argue(int Id_Argue, int Id_User)
    {
        try
        {
            ParametersList param_Dislike_Argue = new ParametersList();
            param_Dislike_Argue.Add("Id_Argue", Id_Argue);
            param_Dislike_Argue.Add("Id_User", Id_User);

            data.Insert("Insert_Dislike_Argue", param_Dislike_Argue);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Dislike_Argue(int Id_Argue, int Id_User, int Id_Crit)
    {
        try
        {
            ParametersList param_Dislike_Argue = new ParametersList();
            param_Dislike_Argue.Add("Id_Argue", Id_Argue);
            param_Dislike_Argue.Add("Id_User", Id_User);
            param_Dislike_Argue.Add("Id_Crit", Id_Crit);

            data.Delete("Delete_Dislike_Argue", param_Dislike_Argue);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Like_Argue(int Id_Argue, int Id_User)
    {
        try
        {
            ParametersList param_Like_Argue = new ParametersList();
            param_Like_Argue.Add("Id_Argue", Id_Argue);
            param_Like_Argue.Add("Id_User", Id_User);

            data.Delete("Delete_Like_Argue", param_Like_Argue);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
    }


}