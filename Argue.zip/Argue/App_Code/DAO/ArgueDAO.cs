﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ArgueDAO
/// </summary>
public class ArgueDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public ArgueDAO()  { }

    public ArgueOBJ Get_Argue(int Id_Argue)
    {
        ArgueOBJ Argue = new ArgueOBJ();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_Argue = new ParametersList();
            param_Argue.Add("Id_Argue", Id_Argue);

            data.request("Get_Argue", param_Argue, ref dt);

            Argue.Id = Id_Argue;
            Argue.Id_PoC = Convert.ToInt32(dt.Rows[0]["Id_PoC"]);
            Argue.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
            Argue.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
            Argue.PoC = Convert.ToBoolean(dt.Rows[0]["PoC"]);
            Argue.Content = dt.Rows[0]["Content"].ToString();
            Argue.NbReponse = Convert.ToInt32(dt.Rows[0]["NbReponse"]);
            Argue.NbLike = Convert.ToInt32(dt.Rows[0]["NbLike"]);
            Argue.NbDisLike = Convert.ToInt32(dt.Rows[0]["NbDisLike"]);
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return Argue;
    }

    /// <summary>
    /// Remonte la liste des Argues relatif à un PoC
    /// </summary>
    /// <param name="Id_PoC"></param>
    /// <returns></returns>
    public List<ArgueOBJ> Get_ListArgue(int Id_PoC)
    {
        List<ArgueOBJ> LstArgue = new List<ArgueOBJ>();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_LstArgue = new ParametersList();
            param_LstArgue.Add("Id_PoC", Id_PoC);

            data.request("Get_LstArgue", param_LstArgue, ref dt);
            foreach(DataRow dr in dt.Rows)
            {
                LstArgue.Add(new ArgueDAO().Get_Argue(Convert.ToInt32(dr["Id_Argue"])));
            }         
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return LstArgue;
    }
}