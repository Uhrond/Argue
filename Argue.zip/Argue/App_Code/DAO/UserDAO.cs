﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de User_DAO
/// </summary>
public class UserDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);
    public string Error = "";
    public Boolean IsError = false;
    public UserDAO() { }

    public UserOBJ Get_User(int Id_User)
    {
        UserOBJ User = new UserOBJ();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_User = new ParametersList();
                param_User.Add("Id_User", Id_User);

                data.request("Get_User", param_User, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                User.Id = Id_User;
                User.Nom = dt.Rows[0]["Nom"].ToString();
                User.Prenom = dt.Rows[0]["Prenom"].ToString();
                User.Login = dt.Rows[0]["Login"].ToString();
                User.Mail = dt.Rows[0]["Mail"].ToString();
                User.DateInscription = Convert.ToDateTime(dt.Rows[0]["DateInscription"]);
                User.Mdp = dt.Rows[0]["Mdp"].ToString();
                User.Avatar = dt.Rows[0]["Avatar"].ToString();
            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            /* No Bdd */
            User.Id = Id_User;
            User.Nom = "TAILLEFERT";
            User.Prenom = "Savinien";
            User.Login = "Uhrond";
            User.Mail = "s.t@g.c";
            User.DateInscription = Convert.ToDateTime("01/01/2016");
            User.Mdp = "123456";
            User.Avatar = "";
        }
        return User;
    }

}