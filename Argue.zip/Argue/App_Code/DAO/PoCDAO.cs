﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de PoC_DAO
/// </summary>
public class PoCDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public PoCDAO() { }

    public PoCOBJ Get_PoC(int Id_PoC)
    {
        PoCOBJ PoC = new PoCOBJ();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_Poc = new ParametersList();
            param_Poc.Add("Id_PoC", Id_PoC);

            data.request("Get_PoC", param_Poc, ref dt);

            PoC.Id = Id_PoC;
            PoC.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
            PoC.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
            PoC.Titre = dt.Rows[0]["Titre"].ToString();
            PoC.Content = dt.Rows[0]["Content"].ToString();
            PoC.NbVotePour = Convert.ToInt32(dt.Rows[0]["NbVotePour"]);
            PoC.NbVoteContre = Convert.ToInt32(dt.Rows[0]["NbVoteContre"]);
            PoC.NbVue = Convert.ToInt32(dt.Rows[0]["NbVue"]);
            PoC.NbArgue = Convert.ToInt32(dt.Rows[0]["NbArgue"]);
        }
        catch(Exception e)
        {
            new Error(e);
        }
        return PoC;
    }
}