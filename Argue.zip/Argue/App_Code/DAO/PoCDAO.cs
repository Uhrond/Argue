﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de PoC_DAO
/// </summary>
public class PoCDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public PoCDAO() { }

    public PoCOBJ Get_PoC(int Id_PoC)
    {
        PoCOBJ PoC = new PoCOBJ();
        try
        {
            DataTable dt = new DataTable();
            ParametersList param_Poc = new ParametersList();
            param_Poc.Add("Id_PoC", Id_PoC);

            data.request("Get_PoC", param_Poc, ref dt);

            PoC.Id = Id_PoC;
            PoC.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
            PoC.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
            PoC.Titre = dt.Rows[0]["Titre"].ToString();
            PoC.Content = dt.Rows[0]["Content"].ToString();
            PoC.NbVotePour = Convert.ToInt32(dt.Rows[0]["NbVotePour"]);
            PoC.NbVoteContre = Convert.ToInt32(dt.Rows[0]["NbVoteContre"]);
            PoC.NbVue = Convert.ToInt32(dt.Rows[0]["NbVue"]);
            PoC.NbArgue = Convert.ToInt32(dt.Rows[0]["NbArgue"]);
        }
        catch (Exception e)
        {
            new Error(e);
        }

        /* No Bdd */
        //PoC.Id = Id_PoC;
        //PoC.User = new UserDAO().Get_User(1);
        //PoC.DateCreation = Convert.ToDateTime("07/11/2016");
        //PoC.Titre = "Pour ou Contre bla bla";
        //PoC.Content = "orem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate ac tortor ut vulputate. Proin nisl elit, sodales id venenatis at, placerat id arcu. Maecenas imperdiet, mauris quis fermentum lacinia, enim diam condimentum mi, nec convallis felis diam ut leo. Mauris auctor vel arcu nec efficitur. Fusce sollicitudin risus in mauris finibus, sit amet lobortis turpis tristique. In ac venenatis lorem, at tempus quam. Vestibulum mauris velit, varius a nunc id, finibus pharetra orci. Nulla dignissim, ligula quis egestas tempus, nisl tellus ultrices justo, et commodo quam sem dictum leo. Vestibulum lobortis tellus egestas, dapibus urna in, vehicula metus. Donec gravida, ligula quis aliquam dignissim, ipsum diam scelerisque diam, eu malesuada sapien est quis tellus. Fusce cursus ultricies porttitor. Integer condimentum, lacus at placerat sodales, arcu est porta elit, in euismod nibh velit ut est. Nam aliquam dui id felis dapibus dictum. In hac habitasse platea dictumst. Duis sit amet orci ultrices, lobortis odio nec, pulvinar ante. Cras non neque pellentesque, dapibus velit quis, ultrices ipsum. ";
        //PoC.NbVotePour = 100;
        //PoC.NbVoteContre = 50;
        //PoC.NbVue = 1534;
        //PoC.NbArgue = 3;



        return PoC;
    }
}