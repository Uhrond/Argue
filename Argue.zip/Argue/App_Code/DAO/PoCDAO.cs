﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de PoC_DAO
/// </summary>
public class PoCDAO
{
    DataConnection data = new DataConnection(ConfigurationManager.ConnectionStrings["Bdd"].ConnectionString);

    public PoCDAO() { }

    public PoCOBJ Get_PoC(int Id_PoC)
    {
        PoCOBJ PoC = new PoCOBJ();
        if (ConfigurationManager.AppSettings["Dev_Prod"].ToString() == "PROD")
        {
            try
            {
                DataTable dt = new DataTable();
                ParametersList param_Poc = new ParametersList();
                param_Poc.Add("Id_PoC", Id_PoC);

                data.request("Get_PoC", param_Poc, ref dt);

                if (data.IsError)
                    new Error(data.MessageErreur);

                PoC.Id = Id_PoC;
                PoC.User = new UserDAO().Get_User(Convert.ToInt32(dt.Rows[0]["Id_User"]));
                PoC.DateCreation = Convert.ToDateTime(dt.Rows[0]["DateCreation"]);
                PoC.Titre = dt.Rows[0]["Titre"].ToString();
                PoC.Content = dt.Rows[0]["Content"].ToString();
                PoC.NbVotePour = Convert.ToInt32(dt.Rows[0]["NbVotePour"]);
                PoC.NbVoteContre = Convert.ToInt32(dt.Rows[0]["NbVoteContre"]);
                PoC.NbVue = Convert.ToInt32(dt.Rows[0]["NbVue"]);
                PoC.NbArgue = Convert.ToInt32(dt.Rows[0]["NbArgue"]);
            }
            catch (Exception e)
            {
                new Error(e);
            }
        }
        else
        {
            /* No Bdd */
            PoC.Id = Id_PoC;
            PoC.User = new UserDAO().Get_User(1);
            PoC.DateCreation = Convert.ToDateTime("07/11/2016");
            PoC.Titre = "Pour ou Contre bla bla";
            PoC.Content = "orem ipsum dolor sit amet, consectetur adipiscing elit. Proin vulputate ac tortor ut vulputate. Proin nisl elit, sodales id venenatis at, placerat id arcu. Maecenas imperdiet, mauris quis fermentum lacinia, enim diam condimentum mi, nec convallis felis diam ut leo. Mauris auctor vel arcu nec efficitur. Fusce sollicitudin risus in mauris finibus, sit amet lobortis turpis tristique. In ac venenatis lorem, at tempus quam. Vestibulum mauris velit, varius a nunc id, finibus pharetra orci. Nulla dignissim, ligula quis egestas tempus, nisl tellus ultrices justo, et commodo quam sem dictum leo. Vestibulum lobortis tellus egestas, dapibus urna in, vehicula metus. Donec gravida, ligula quis aliquam dignissim, ipsum diam scelerisque diam, eu malesuada sapien est quis tellus. Fusce cursus ultricies porttitor. Integer condimentum, lacus at placerat sodales, arcu est porta elit, in euismod nibh velit ut est. Nam aliquam dui id felis dapibus dictum. In hac habitasse platea dictumst. Duis sit amet orci ultrices, lobortis odio nec, pulvinar ante. Cras non neque pellentesque, dapibus velit quis, ultrices ipsum. ";
            PoC.NbVotePour = 100;
            PoC.NbVoteContre = 50;
            PoC.NbVue = 1534;
            PoC.NbArgue = 3;
        }


        return PoC;
    }

    public List<int> Get_Dislike_PoC(int Id_PoC, int Id_User)
    {
        DataTable dt = new DataTable();
        List<int> lst = new List<int>();
        try
        {
            ParametersList param_Dislike_PoC = new ParametersList();
            param_Dislike_PoC.Add("Id_PoC", Id_PoC);
            param_Dislike_PoC.Add("Id_User", Id_User);

            data.request("Get_Dislike_PoC", param_Dislike_PoC, ref dt);

            if (data.IsError)
                new Error(data.MessageErreur);

            foreach (DataRow dr in dt.Rows)
                lst.Add(Convert.ToInt32(dr["Id_Crit"]));
        }
        catch (Exception e)
        {
            new Error(e);
        }
        return lst;
    }

    public Boolean Get_Like_PoC(int Id_PoC, int Id_User)
    {
        int IsLike = -1;
        try
        {
            ParametersList param_Like_PoC = new ParametersList();
            param_Like_PoC.Add("Id_PoC", Id_PoC);
            param_Like_PoC.Add("Id_User", Id_User);

            data.request("Get_Like_PoC", param_Like_PoC, ref IsLike);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
        if (IsLike <= 0)
            return false;
        else
            return true;
    }

    public void Insert_Like_PoC(int Id_PoC, int Id_User)
    {
        try
        {
            ParametersList param_Like_PoC = new ParametersList();
            param_Like_PoC.Add("Id_PoC", Id_PoC);
            param_Like_PoC.Add("Id_User", Id_User);

            data.Insert("Insert_Like_PoC", param_Like_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Insert_Dislike_PoC(int Id_PoC, int Id_User)
    {
        try
        {
            ParametersList param_Dislike_PoC = new ParametersList();
            param_Dislike_PoC.Add("Id_PoC", Id_PoC);
            param_Dislike_PoC.Add("Id_User", Id_User);

            data.Insert("Insert_Dislike_PoC", param_Dislike_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Dislike_PoC(int Id_PoC, int Id_User, int Id_Crit)
    {
        try
        {
            ParametersList param_Dislike_PoC = new ParametersList();
            param_Dislike_PoC.Add("Id_PoC", Id_PoC);
            param_Dislike_PoC.Add("Id_User", Id_User);
            param_Dislike_PoC.Add("Id_Crit", Id_Crit);

            data.Delete("Delete_Dislike_PoC", param_Dislike_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Delete_Like_PoC(int Id_PoC, int Id_User)
    {
        try
        {
            ParametersList param_Like_PoC = new ParametersList();
            param_Like_PoC.Add("Id_PoC", Id_PoC);
            param_Like_PoC.Add("Id_User", Id_User);

            data.Delete("Delete_Like_PoC", param_Like_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

    public void Insert_Vote_PoC(int Id_PoC, int Id_User, bool Vote)
    {
        try
        {
            ParametersList param_Vote_PoC = new ParametersList();
            param_Vote_PoC.Add("Id_PoC", Id_PoC);
            param_Vote_PoC.Add("Id_User", Id_User);
            param_Vote_PoC.Add("Vote", Vote);

            data.Insert("Insert_VotePoC", param_Vote_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);

        }
        catch (Exception e)
        {
            new Error(e);
        }
    }



    public void Insert_Vue_PoC(int Id_PoC)
    {
        try
        {
            string Id_User = "";
            if (HttpContext.Current.Session["User"] != null)
                Id_User = ((UserOBJ)HttpContext.Current.Session["User"]).Id.ToString();
            else
                Id_User = new GetIp().GetIPAddress();

            ParametersList param_Vue_PoC = new ParametersList();
            param_Vue_PoC.Add("Id_PoC", Id_PoC);
            param_Vue_PoC.Add("Id_User", Id_User);

            data.Insert("Insert_VuePoC", param_Vue_PoC);

            if (data.IsError)
                new Error(data.MessageErreur);
        }
        catch (Exception e)
        {
            new Error(e);
        }
    }

}